# == Schema Information
#
# Table name: rams
#
#  id          :bigint           not null, primary key
#  description :text
#  height      :decimal(, )
#  name        :string
#  price       :decimal(, )
#  quantity    :integer
#  created_at  :datetime         not null
#  updated_at  :datetime         not null
#
require "test_helper"

class RamTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
