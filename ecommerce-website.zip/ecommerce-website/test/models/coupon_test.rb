# == Schema Information
#
# Table name: coupons
#
#  id                  :bigint           not null, primary key
#  code                :string
#  discount_percentage :integer
#  expiration_date     :date
#  created_at          :datetime         not null
#  updated_at          :datetime         not null
#
require "test_helper"

class CouponTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
