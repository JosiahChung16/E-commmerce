# == Schema Information
#
# Table name: gpus
#
#  id          :bigint           not null, primary key
#  description :text
#  length      :integer
#  name        :string
#  price       :decimal(, )
#  quantity    :integer
#  slots       :decimal(, )
#  created_at  :datetime         not null
#  updated_at  :datetime         not null
#
class Gpu < ApplicationRecord
end

Gpu.create!(
    name: 'Radeon 7900xtx',
    price: 999.00,
    description: '',
    quantity: 2,
    length: 287,
    slots: 2.5,
)

Gpu.create!(
    name: 'Radeon 7900xt',
    price: 849.00,
    description: '',
    quantity: 2,
    length: 276,
    slots: 2.5,
)

Gpu.create!(
    name: 'Radeon 6950xt',
    price: 699.00,
    description: '',
    quantity: 2,
    length: 267,
    slots: 2.5,
)

Gpu.create!(
    name: 'Nvidia 4090',
    price: 1599.99,
    description: '',
    quantity: 1,
    length: 304,
    slots: 3,
)

Gpu.create!(
    name: 'Nvidia 4080',
    price: 1199.99,
    description: '',
    quantity: 2,
    length: 304,
    slots: 3,
)

Gpu.create!(
    name: 'Nvidia 4070',
    price: 599.99,
    description: '',
    quantity: 3,
    length: 305,
    slots: 2,
)