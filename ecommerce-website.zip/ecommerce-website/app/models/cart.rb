# == Schema Information
#
# Table name: carts
#
#  id         :bigint           not null, primary key
#  created_at :datetime         not null
#  updated_at :datetime         not null
#  coupon_id  :bigint
#  user_id    :bigint
#
# Indexes
#
#  index_carts_on_coupon_id  (coupon_id)
#  index_carts_on_user_id    (user_id)
#
# Foreign Keys
#
#  fk_rails_...  (user_id => users.id)
#
class Cart < ApplicationRecord
  belongs_to :user, optional: true
  belongs_to :coupon, optional: true
  has_many :cart_items, dependent: :destroy

  def discount_amount(coupon_code)
    if coupon_code.present?
      coupon = Coupon.find_by(code: coupon_code)
  
      if coupon.present? && coupon.expiration_date > Date.today
        total_price * (coupon.discount_percentage.to_f / 100)
      else
        0
      end
    else
      0
    end
  end
  
  
  def total_price
    cart_items.sum(&:total_price)
  end

  def discounted_total_price(coupon_code)
    if coupon_code.present?
      coupon = Coupon.find_by(code: coupon_code)

      if coupon.present? && coupon.expiration_date > Date.today
        total_price * (1 - coupon.discount_percentage.to_f / 100)
      else
        total_price
      end
    else
      total_price
    end
  end
end
