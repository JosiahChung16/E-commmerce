# == Schema Information
#
# Table name: coupons
#
#  id                  :bigint           not null, primary key
#  code                :string
#  discount_percentage :integer
#  expiration_date     :date
#  created_at          :datetime         not null
#  updated_at          :datetime         not null
#
class Coupon < ApplicationRecord
    has_many :orders
    has_many :carts
    validates :code, presence: true, uniqueness: true
    validates :discount_percentage, presence: true, numericality: { greater_than: 0 }
    validates :expiration_date, presence: true

    def valid_for_use?
        expiration_date > Date.today
    end
end
