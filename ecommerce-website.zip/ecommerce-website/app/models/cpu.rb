# == Schema Information
#
# Table name: cpus
#
#  id          :bigint           not null, primary key
#  description :text
#  name        :string
#  price       :decimal(, )
#  quantity    :integer
#  socket      :string
#  tdp         :string
#  created_at  :datetime         not null
#  updated_at  :datetime         not null
#
class Cpu < ApplicationRecord
end

Cpu.create!(
    name: 'AMD Ryzen 7600x',
    price: 249.00,
    description: '',
    quantity: 2,
    tdp: 'TDP 105W',
    socket: 'AM5',
)

Cpu.create!(
    name: 'AMD Ryzen 7700x',
    price: 349.00,
    description: '',
    quantity: 2,
    tdp: 'TDP 105W',
    socket: 'AM5',
)

Cpu.create!(
    name: 'AMD Ryzen 7900x',
    price: 449.00,
    description: '',
    quantity: 2,
    tdp: 'TDP 170W',
    socket: 'AM5,'
)

Cpu.create!(
    name: 'Intel 13600k',
    price: 319.80,
    description: '',
    quantity: 2,
    tdp: 'TDP 125W',
    socket: 'LGA 1700',
)

Cpu.create!(
    name: 'Intel 13700k',
    price: 415.88,
    description: '',
    quantity: 2,
    tdp: 'TDP 125W',
    socket: 'LGA 1700',
)

Cpu.create!(
    name: 'Intel 13900k',
    price: 569.99,
    description: '',
    quantity: 2,
    tdp: 'TDP 125W',
    socket: 'LGA 1700',
)

