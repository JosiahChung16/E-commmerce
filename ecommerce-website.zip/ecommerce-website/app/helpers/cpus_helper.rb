module CpusHelper
end
