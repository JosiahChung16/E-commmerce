module CoolersHelper
end
