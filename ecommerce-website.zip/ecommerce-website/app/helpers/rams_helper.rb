module RamsHelper
end
