class MotherboardsController < ApplicationController
    before_action :authenticate_user!, only: [:new, :create, :edit, :update, :destroy]
    before_action :verify_admin, only: [:new, :create, :edit, :update, :destroy]
    before_action :set_motherboard, only: [:show, :edit, :update, :destroy]
    def index
      if params[:search].present?
        @motherboards = Motherboard.where("LOWER(name) LIKE ?", "%#{params[:search].downcase}%")
      else
        @motherboards = Motherboard.all
      end
      render :index
    end

    def show
        @motherboard = Motherboard.find(params[:id])
        render :show
    end
    def new
        @motherboard = Motherboard.new
    end
    
    def create
        @motherboard = Motherboard.new(motherboard_params)
        if @motherboard.save
          flash[:notice] = "motherboard created successfully."
          redirect_to motherboard_path(@motherboard)
        else
          flash[:alert] = "Failed to create motherboard."
          render :new
        end
    end
    
    def edit
    end
    
    def update
        if @motherboard.update(motherboard_params)
          flash[:notice] = "motherboard updated successfully."
          redirect_to motherboard_path(@motherboard)
        else
          flash[:alert] = "Failed to update motherboard."
          render :edit
        end
    end
    
    def destroy
        @motherboard.destroy
        flash[:notice] = "motherboard deleted successfully."
        redirect_to motherboards_path
    end
    
    private
    
    def set_motherboard
        @motherboard = Motherboard.find(params[:id])
    end
    
    def motherboard_params
        params.require(:motherboard).permit(:name, :price, :description)
    end
    def verify_admin
        unless current_user.admin?
          flash[:alert] = "You do not have the required permissions to access this page."
          redirect_to motherboards_path
        end
    end
end
