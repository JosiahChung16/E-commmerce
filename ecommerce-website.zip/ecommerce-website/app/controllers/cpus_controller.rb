class CpusController < ApplicationController
    before_action :authenticate_user!, only: [:new, :create, :edit, :update, :destroy]
    before_action :verify_admin, only: [:new, :create, :edit, :update, :destroy]
    before_action :set_cpu, only: [:show, :edit, :update, :destroy]
    def add_to_cart
        @cpu = Cpu.find(params[:id])
        quantity = params[:quantity].to_i
        cart = session[:cart] || {}
        cart_item = cart[@cpu.id.to_s] || { "quantity" => 0 }
        cart_item["quantity"] += quantity
        cart[@cpu.id.to_s] = cart_item
        session[:cart] = cart
        redirect_back fallback_location: root_path
    end
    def index
        if params[:search].present?
          @cpus = Cpu.where("LOWER(name) LIKE ?", "%#{params[:search].downcase}%")
        else
          @cpus = Cpu.all
        end
        render :index
      end

    def show
        @cpu = Cpu.find(params[:id])
        render :show
    end
    def new
        @cpu = Cpu.new
    end
    
    def create
        @cpu = Cpu.new(cpu_params)
        if @cpu.save
          flash[:notice] = "created successfully."
          redirect_to cpu_path(@cpu)
        else
          flash[:alert] = "Failed to create."
          render :new
        end
    end
    
    def edit
    end
    
    def update
        if @cpu.update(cpu_params)
          flash[:notice] = "updated successfully."
          redirect_to cpu_path(@cpu)
        else
          flash[:alert] = "Failed to update."
          render :edit
        end
    end
    
    def destroy
        @cpu.destroy
        flash[:notice] = "deleted successfully."
        redirect_to cpus_path
    end
    
    private
    
    def set_cpu
        @cpu = Cpu.find(params[:id])
    end
    
    def cpu_params
        params.require(:cpu).permit(:name, :price, :description)
    end
    def verify_admin
        unless current_user.admin?
          flash[:alert] = "You do not have the required permissions to access this page."
          redirect_to cpus_path
        end
    end

end
