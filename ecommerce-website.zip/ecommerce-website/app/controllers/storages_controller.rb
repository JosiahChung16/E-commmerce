class StoragesController < ApplicationController
    before_action :authenticate_user!, only: [:new, :create, :edit, :update, :destroy]
    before_action :verify_admin, only: [:new, :create, :edit, :update, :destroy]
    before_action :set_storage, only: [:show, :edit, :update, :destroy]
    def index
        @storages = Storage.all
        render :index
    end

    def show
        @storage = Storage.find(params[:id])
        render :show
    end
    def new
        @storage = Storage.new
    end
    
    def create
        @storage = Storage.new(storage_params)
        if @storage.save
          flash[:notice] = "storage created successfully."
          redirect_to storage_path(@storage)
        else
          flash[:alert] = "Failed to create storage."
          render :new
        end
    end
    
    def edit
    end
    
    def update
        if @storage.update(storage_params)
          flash[:notice] = "storage updated successfully."
          redirect_to storage_path(@storage)
        else
          flash[:alert] = "Failed to update storage."
          render :edit
        end
    end
    
    def destroy
        @storage.destroy
        flash[:notice] = "storage deleted successfully."
        redirect_to storages_path
    end
    
    private
    
    def set_storage
        @storage = Storage.find(params[:id])
    end
    
    def storage_params
        params.require(:storage).permit(:name, :price, :description)
    end
    def verify_admin
        unless current_user.admin?
          flash[:alert] = "You do not have the required permissions to access this page."
          redirect_to storages_path
        end
    end
end
