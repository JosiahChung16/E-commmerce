class PagesController < ApplicationController

  end
  