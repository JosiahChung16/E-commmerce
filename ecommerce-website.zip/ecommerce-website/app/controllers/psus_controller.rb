class PsusController < ApplicationController
    before_action :authenticate_user!, only: [:new, :create, :edit, :update, :destroy]
    before_action :verify_admin, only: [:new, :create, :edit, :update, :destroy]
    before_action :set_psu, only: [:show, :edit, :update, :destroy]
    def index
      if params[:search].present?
        @psus = Psu.where("LOWER(name) LIKE ?", "%#{params[:search].downcase}%")
      else
        @psus = Psu.all
      end
      render :index
    end

    def show
        @psu = Psu.find(params[:id])
        render :show
    end
    def new
        @psu = Psu.new
    end
    
    def create
        @psu = Psu.new(psu_params)
        if @psu.save
          flash[:notice] = "psu created successfully."
          redirect_to psu_path(@psu)
        else
          flash[:alert] = "Failed to create psu."
          render :new
        end
    end
    
    def edit
    end
    
    def update
        if @psu.update(psu_params)
          flash[:notice] = "psu updated successfully."
          redirect_to psu_path(@psu)
        else
          flash[:alert] = "Failed to update psu."
          render :edit
        end
    end
    
    def destroy
        @psu.destroy
        flash[:notice] = "psu deleted successfully."
        redirect_to psus_path
    end
    
    private
    
    def set_psu
        @psu = Psu.find(params[:id])
    end
    
    def psu_params
        params.require(:psu).permit(:name, :price, :description)
    end
    def verify_admin
        unless current_user.admin?
          flash[:alert] = "You do not have the required permissions to access this page."
          redirect_to psus_path
        end
    end
end
