class GpusController < ApplicationController
    before_action :authenticate_user!, only: [:new, :create, :edit, :update, :destroy]
    before_action :verify_admin, only: [:new, :create, :edit, :update, :destroy]
    before_action :set_gpu, only: [:show, :edit, :update, :destroy]
    def index
      if params[:search].present?
        @gpus = Gpu.where("LOWER(name) LIKE ?", "%#{params[:search].downcase}%")
      else
        @gpus = Gpu.all
      end
      render :index
    end
  
    def show
      @gpu = Gpu.find(params[:id])
      render :show
    end
    def new
        @gpu = Gpu.new
    end
    
    def create
        @gpu = Gpu.new(gpu_params)
        if @gpu.save
          flash[:notice] = "gpu created successfully."
          redirect_to gpu_path(@gpu)
        else
          flash[:alert] = "Failed to create gpu."
          render :new
        end
    end
    
    def edit
    end
    
    def update
        if @gpu.update(gpu_params)
          flash[:notice] = "gpu updated successfully."
          redirect_to gpu_path(@gpu)
        else
          flash[:alert] = "Failed to update gpu."
          render :edit
        end
    end
    
    def destroy
        @gpu.destroy
        flash[:notice] = "gpu deleted successfully."
        redirect_to gpus_path
    end
    
    private
    
    def set_gpu
        @gpu = Gpu.find(params[:id])
    end
    
    def gpu_params
        params.require(:gpu).permit(:name, :price, :description)
    end
    def verify_admin
        unless current_user.admin?
          flash[:alert] = "You do not have the required permissions to access this page."
          redirect_to gpus_path
        end
    end
end
