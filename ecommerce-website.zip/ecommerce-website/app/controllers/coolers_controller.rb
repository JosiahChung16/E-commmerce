class CoolersController < ApplicationController
    before_action :authenticate_user!, only: [:new, :create, :edit, :update, :destroy]
    before_action :verify_admin, only: [:new, :create, :edit, :update, :destroy]
    before_action :set_cooler, only: [:show, :edit, :update, :destroy]
    def index
      if params[:search].present?
        @coolers = Cooler.where("LOWER(name) LIKE ?", "%#{params[:search].downcase}%")
      else
        @coolers = Cooler.all
      end
      render :index
    end
  
    def show
      @cooler = Cooler.find(params[:id])
      render :show
    end
    
    def new
        @cooler = Cooler.new
    end
    
    def create
        @cooler = Cooler.new(case_params)
        if @cooler.save
          flash[:notice] = "Cooler created successfully."
          redirect_to cooler_path(@cooler)
        else
          flash[:alert] = "Failed to create case."
          render :new
        end
    end
    
    def edit
    end
    
    def update
        if @cooler.update(cooler_params)
          flash[:notice] = "updated successfully."
          redirect_to cooler_path(@cooler)
        else
          flash[:alert] = "Failed to update."
          render :edit
        end
    end
    
    def destroy
        @cooler.destroy
        flash[:notice] = "deleted successfully."
        redirect_to coolers_path
    end
    
    private
    
    def set_cooler
        @cooler = Cooler.find(params[:id])
    end
    
    def cooler_params
        params.require(:cooler).permit(:name, :price, :description)
    end
    def verify_admin
        unless current_user.admin?
          flash[:alert] = "You do not have the required permissions to access this page."
          redirect_to coolers_path
        end
    end

end
