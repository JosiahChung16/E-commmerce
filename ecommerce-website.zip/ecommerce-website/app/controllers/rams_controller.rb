class RamsController < ApplicationController
    before_action :authenticate_user!, only: [:new, :create, :edit, :update, :destroy]
    before_action :verify_admin, only: [:new, :create, :edit, :update, :destroy]
    before_action :set_ram, only: [:show, :edit, :update, :destroy]
    def index
      if params[:search].present?
        @rams = Ram.where("LOWER(name) LIKE ?", "%#{params[:search].downcase}%")
      else
        @rams = Ram.all
      end
      render :index
    end

    def show
        @ram = Ram.find(params[:id])
        render :show
    end
    def new
        @ram = Ram.new
    end
    
    def create
        @ram = Ram.new(ram_params)
        if @ram.save
          flash[:notice] = "ram created successfully."
          redirect_to ram_path(@ram)
        else
          flash[:alert] = "Failed to create ram."
          render :new
        end
    end
    
    def edit
    end
    
    def update
        if @ram.update(ram_params)
          flash[:notice] = "ram updated successfully."
          redirect_to ram_path(@ram)
        else
          flash[:alert] = "Failed to update ram."
          render :edit
        end
    end
    
    def destroy
        @ram.destroy
        flash[:notice] = "ram deleted successfully."
        redirect_to rams_path
    end
    
    private
    
    def set_ram
        @ram = Ram.find(params[:id])
    end
    
    def ram_params
        params.require(:ram).permit(:name, :price, :description)
    end
    def verify_admin
        unless current_user.admin?
          flash[:alert] = "You do not have the required permissions to access this page."
          redirect_to rams_path
        end
    end
end
