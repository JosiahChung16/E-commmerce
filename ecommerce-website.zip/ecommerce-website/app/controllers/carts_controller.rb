class CartsController < ApplicationController
  def show
    @cart = current_or_guest_cart
    @cart_items = @cart.cart_items.includes(:productable)
  end
  
  def empty
    flash[:notice] = "Your cart is empty. Add some items to it first."
    redirect_to components_path
  end

  def create
    @cart = current_or_guest_cart
    return redirect_to(components_path, alert: 'Please sign in or sign up to add items to your cart.') unless @cart

    productable = find_productable
    @cart_item = @cart.cart_items.find_or_initialize_by(productable: productable)

    @cart_item.quantity = (@cart_item.quantity || 0) + params[:quantity].to_i
    @cart_item.save

    redirect_to cart_path(@cart)
  end

  def apply_coupon
    coupon_code = params[:coupon_code].presence
    coupon = Coupon.find_by(code: coupon_code) if coupon_code
  
    if coupon_code.blank?
      session[:coupon_code] = nil
      session[:coupon_id] = nil
      flash[:notice] = 'Coupon removed.'
    elsif coupon && coupon.valid_for_use?
      current_or_guest_cart.update(coupon: coupon)
      session[:coupon_code] = coupon.code
      session[:coupon_id] = coupon.id
      flash[:notice] = 'Coupon applied successfully!'
    else
      flash[:alert] = 'Invalid or expired coupon code.'
    end
  
    redirect_to cart_path
  end
  
  
  
  private

  def find_productable
    params[:type].constantize.find(params[:id])
  end
end