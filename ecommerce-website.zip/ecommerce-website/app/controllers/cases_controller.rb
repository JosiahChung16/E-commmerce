class CasesController < ApplicationController
    before_action :authenticate_user!, only: [:new, :create, :edit, :update, :destroy]
    before_action :verify_admin, only: [:new, :create, :edit, :update, :destroy]
    before_action :set_case, only: [:show, :edit, :update, :destroy]
    def index
      if params[:search].present?
        @cases = Case.where("LOWER(name) LIKE ?", "%#{params[:search].downcase}%")
      else
        @cases = Case.all
      end
      render :index
    end

    def show
        @case = Case.find(params[:id])
        render :show
    end

    def new
        @case = Case.new
    end
    
    def create
        @case = Case.new(case_params)
        if @case.save
          flash[:notice] = "Case created successfully."
          redirect_to case_path(@case)
        else
          flash[:alert] = "Failed to create case."
          render :new
        end
    end
    
    def edit
    end
    
    def update
        if @case.update(case_params)
          flash[:notice] = "Case updated successfully."
          redirect_to case_path(@case)
        else
          flash[:alert] = "Failed to update case."
          render :edit
        end
    end
    
    def destroy
        @case.destroy
        flash[:notice] = "Case deleted successfully."
        redirect_to cases_path
    end
    
    private
    
    def set_case
        @case = Case.find(params[:id])
    end
    
    def case_params
        params.require(:case).permit(:name, :price, :description)
    end
    def verify_admin
        unless current_user.admin?
          flash[:alert] = "You do not have the required permissions to access this page."
          redirect_to cases_path
        end
    end
end
