# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the bin/rails db:seed command (or created alongside the database with db:setup).
#
# Examples:
#
#   movies = Movie.create([{ name: "Star Wars" }, { name: "Lord of the Rings" }])
#   Character.create(name: "Luke", movie: movies.first)


user1 = User.find_or_create_by(email: 'bob@email.com') do |user|
    user.password = 'password'
end
  
user2 = User.find_or_create_by(email: 'alice@email.com') do |user|
    user.password = 'password'
end

admin = User.find_or_create_by(email: 'admin@example.com') do |user|
  user.password = 'password'
  user.admin = true
end

Coupon.create!(code: 'CODE10', discount_percentage: 10, expiration_date: '2023-12-31')


ShippingAddress.create!(
  user: user1,
  full_name: "John Doe",
  address: "123 Main St",
  apartment: "",
  city: "New York",
  state: "NY",
  zipcode: "10001",
  phone_number: "555-123-4567",
  country: "USA"
)

ShippingAddress.create!(
  user: user2,
  full_name: "Alice Smith",
  address: "456 Market St",
  apartment: "Apt 3",
  city: "San Francisco",
  state: "CA",
  zipcode: "94102",
  phone_number: "555-987-6543",
  country: "USA"
)
ShippingAddress.create!(
  user: admin,
  full_name: "Admin User",
  address: "789 Admin St",
  apartment: "",
  city: "Los Angeles",
  state: "CA",
  zipcode: "90001",
  phone_number: "555-111-2222",
  country: "USA"
)

